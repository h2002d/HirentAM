﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Hirent.Models;
namespace Hirent.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.ParentCategories = Models.ParentCategory.GetCategory(null);
            ViewBag.MainCategories = Models.Category.GetCategory(null).Count>4? Models.Category.GetCategory(null).Take(4): Models.Category.GetCategory(null);
            ViewBag.MainProducts = Models.Product.GetProduct(null).Count>12? Models.Product.GetProduct(null).Take(12): Models.Product.GetProduct(null);
            return PartialView();
        }

        public ActionResult Category(int id)
        {
            ViewBag.ParentCategories = Models.ParentCategory.GetCategory(null);
            ViewBag.CategoryName = Models.Category.GetCategory(id).First().Name;
            var products = Models.Product.GetProductByCategoryId(id);
            return PartialView(products);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}