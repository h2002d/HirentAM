﻿using Hirent.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Hirent.Controllers
{
    [Authorize(Roles ="Administrator")]
    public class ProductController : Controller
    {
        // GET: Product
        public ActionResult Index()
        {
            var productList = Product.GetProduct(null);
            return View(productList);
        }

        public ActionResult Create()
        {
            ViewBag.Categories = Models.Category.GetCategory(null);
            return View();
        }

        public ActionResult Edit(int id)
        {
            var product = Product.GetProduct(id).First();
            ViewBag.Categories = Models.Category.GetCategory(null);
            return View("Create",product);
        }

        [HttpPost]
        public ActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                if (product.Id != null && product.File == null)
                {
                    product.Save();
                    return RedirectToAction("Index");
                }
                string targetFolder = HttpContext.Server.MapPath("~/images");
                string targetPath = Path.Combine(targetFolder, product.File.FileName);
                product.File.SaveAs(targetPath);
                product.ImageSource = "/images/"+ product.File.FileName;
                product.Save();
                return RedirectToAction("Index");
            }
            return View();
        }

        public ActionResult Delete(int id)
        {
            Product.Delete(id);
            return RedirectToAction("Index");
        }
    }
}