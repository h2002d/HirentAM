﻿using Hirent.DAO;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace Hirent.Models
{
    public class Product
    {
        static ProductDAO DAO = new ProductDAO();
        public int? Id { get; set; }
        public string Name { get; set; }
        public string ImageSource { get; set; }

        public int CategoryId { get; set; }
        public decimal Price { get; set; }

        [DataType(DataType.Upload)]
        public HttpPostedFileBase File { get; set; }
        public void Save()
        {
            DAO.saveProduct(this);
        }

        public static List<Product> GetProduct(int? id)
        {
            return DAO.GetProducts(id);
        }

        public static List<Product> GetProductByCategoryId(int id)
        {
            return DAO.GetProductsByCategoryId(id);
        }

        public static void Delete(int id)
        {
            DAO.deleteProduct(id);
        }
    }
}